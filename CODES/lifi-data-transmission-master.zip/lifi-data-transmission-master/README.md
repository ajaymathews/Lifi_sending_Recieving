# lifi-data-transmission
data /image/audio  transfer through light using laser and solar panels/photo diodes.
